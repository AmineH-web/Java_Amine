package modele;

public interface PrimeR {
    final double prime = 2000;
}
